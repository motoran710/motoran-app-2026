پروژه موتوران - نسخه آماده ساخت ابری
این پروژه باید با فایل‌های داخل همین پوشه در ریشه Repository قرار بگیرد.
Workflow ساخت APK در .github/workflows/build-apk.yml قرار دارد.
