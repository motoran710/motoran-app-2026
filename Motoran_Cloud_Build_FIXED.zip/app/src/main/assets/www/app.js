let ads=JSON.parse(localStorage.getItem('motoran_ads_v2')||'null')||[
{title:'پژو 206',type:'خودرو',price:850000000,city:'سیرجان',phone:'',desc:'خودروی شخصی، تمیز و آماده انتقال',photo:''},
{title:'هوندا',type:'موتورسیکلت',price:125000000,city:'سیرجان',phone:'',desc:'سالم و آماده استفاده',photo:''}
];
let currentType='همه';
const $=id=>document.getElementById(id);
function go(id){document.querySelectorAll('main section').forEach(s=>s.classList.add('hide'));$(id).classList.remove('hide');render()}
function filterType(t){currentType=t;go('home')}
function money(n){return Number(n||0).toLocaleString('fa-IR')+' تومان'}
function card(a){return `<article class="card">${a.photo?`<img src="${a.photo}">`:''}<span class="tag">${a.type}</span><h3>${esc(a.title)}</h3><div class="muted">📍 ${esc(a.city)}</div><p>${esc(a.desc)}</p><div class="price">${money(a.price)}</div>${a.phone?`<div class="muted">☎️ ${esc(a.phone)}</div>`:''}</article>`}
function esc(x){return String(x||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function filtered(){let q=($('search')?.value||'').trim().toLowerCase();return ads.filter(a=>(currentType==='همه'||a.type===currentType)&&((a.title+a.type+a.city+a.desc).toLowerCase().includes(q)))}
function render(){let f=filtered();$('homeList').innerHTML=ads.filter(a=>currentType==='همه'||a.type===currentType).slice(0,8).map(card).join('')||'<div class="empty">آگهی‌ای وجود ندارد.</div>';if($('adsList'))$('adsList').innerHTML=f.map(card).join('')||'<div class="empty">آگهی‌ای پیدا نشد.</div>';if($('myAds'))$('myAds').innerHTML=ads.map((a,i)=>`<div class="card"><b>${esc(a.title)}</b><div>${money(a.price)}</div><button class="danger" onclick="removeAd(${i})">حذف آگهی</button></div>`).join('')}
function removeAd(i){if(confirm('این آگهی حذف شود؟')){ads.splice(i,1);save();render()}}
function save(){localStorage.setItem('motoran_ads_v2',JSON.stringify(ads))}
function submitAd(){let a={title:$('title').value.trim(),type:$('type').value,price:$('price').value,city:$('city').value.trim(),phone:$('phone').value.trim(),desc:$('desc').value.trim(),photo:window._photo||''};if(!a.title||!a.price||!a.city){$('msg').textContent='عنوان، قیمت و شهر را کامل کنید.';return}ads.unshift(a);save();$('msg').textContent='آگهی در نسخه آزمایشی ثبت شد. برای پرداخت واقعی باید درگاه متصل شود.';['title','price','city','phone','desc'].forEach(x=>$(x).value='');window._photo='';$('preview').innerHTML='';go('ads')}
$('photo').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{window._photo=r.result;$('preview').innerHTML='<img src="'+r.result+'">'};r.readAsDataURL(f)})
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
render();